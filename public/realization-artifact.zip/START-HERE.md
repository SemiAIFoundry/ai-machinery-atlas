# Computation-to-FPGA artifact

Start with examples/realization/README.md. Run the declared public toolchain from examples/realization to reproduce the flow. Retain this directory structure for the generated browser summary. Logs, RTL, mapped/routed resources and hashes can be inspected without installing tools. The bitstream is an unqualified tool artifact with automatically assigned IO, not a board programming recipe. Current license and third-party notices are included.

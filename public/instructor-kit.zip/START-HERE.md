# Atlas instructor pack

Start with docs/instructor-kit/README.md and SESSION-PLANS.md. Worksheets and answer keys are usable on paper. Reproducing all contracts requires a matching full atlas source checkout; set ATLAS_REPO_ROOT as described in the guide. The pack contains no participant observations. Current license and third-party notices are included.
